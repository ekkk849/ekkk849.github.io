// make-secrets.mjs — keep this file OFF GitHub (it contains every answer).
// Run:  node make-secrets.mjs
// Paste the printed SECRETS object over the one near the bottom of hunt.html.
import { webcrypto as crypto } from "node:crypto";

// ---- edit your hunt here -------------------------------------------------
const ANSWERS = {
  1: "chai_first",      // base64 in an HTML comment
  2: "jalebi",          // hex in the rangoli's data attribute
  3: "mustard_seeds",   // ROT13 on the robots.txt page
  4: "elaichi",         // revealed after cookie visitor=dadi
  5: "kesar",           // revealed after tampering the local storage pass
  6: "dadi hid it in the chai tin", // Vigenère(plaintext, key = answer 5)
};
const COOKIE_UNLOCK = "dadi";      // cookie value that opens clue 4
const PASS_UNLOCK = "vip";         // key used to scramble clue 5's reveal
const REVEAL_4 = "The door creaks open. Inside, a steel dabba with one word scratched on the lid: elaichi";
const REVEAL_5 = "Welcome, VIP. The mehendi artist leans in and whispers the key to the last lock: kesar";
const REWARD = {
  title: "You found Dadi's jhumka!",
  body: "It was in the chai tin the whole time. It always is. You read the source, decoded, rotated, forged a cookie, tampered a token and broke a 16th-century cipher. Dadi is very proud.",
  flag: "0xesha{jhumka_f0und_1n_th3_cha1_t1n}",
  ask: "Screenshot this and send it to me on LinkedIn. I'd love to know who you are.",
};
// --------------------------------------------------------------------------

const enc = new TextEncoder();
const norm = (s) => s.toLowerCase().trim().replace(/\s+/g, " ");
const hex = (buf) => Buffer.from(buf).toString("hex");
const b64 = (buf) => Buffer.from(buf).toString("base64");
const sha = async (s) => hex(await crypto.subtle.digest("SHA-256", enc.encode(norm(s))));
const xor = (text, key) => b64(Buffer.from([...enc.encode(text)].map((b, i) => b ^ key.charCodeAt(i % key.length))));

function vigenere(plain, key) {
  let j = 0;
  return plain.replace(/[a-z]/gi, (c) => {
    const base = c <= "Z" ? 65 : 97;
    const k = key.toLowerCase().charCodeAt(j++ % key.length) - 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + k) % 26) + base);
  });
}

const hashes = {};
for (const [n, a] of Object.entries(ANSWERS)) hashes[n] = await sha(a);

const keyBytes = await crypto.subtle.digest("SHA-256", enc.encode("jhumka:" + norm(ANSWERS[6])));
const key = await crypto.subtle.importKey("raw", keyBytes, "AES-GCM", false, ["encrypt"]);
const iv = crypto.getRandomValues(new Uint8Array(12));
const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(JSON.stringify(REWARD)));

const SECRETS = {
  hashes,
  reveal4: xor(REVEAL_4, COOKIE_UNLOCK),
  reveal5: xor(REVEAL_5, PASS_UNLOCK),
  cipher6: vigenere(ANSWERS[6], ANSWERS[5]),
  vault: { iv: b64(iv), ct: b64(ct) },
};

console.log("L1 comment (base64):", b64(enc.encode(ANSWERS[1])));
console.log("L2 data-secret (hex):", hex(enc.encode(ANSWERS[2])));
console.log("L3 almirah note (rot13):", ANSWERS[3].replace(/[a-z]/g, (c) => String.fromCharCode(((c.charCodeAt(0) - 97 + 13) % 26) + 97)));
console.log("\nconst SECRETS = " + JSON.stringify(SECRETS, null, 2) + ";");
